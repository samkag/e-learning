# Final Project : E-Learning Website
This project is focused on; 
1. Providing computer lessons 
2. Later include other lessons and subjects taught in school
## E-Learning Website Name: Africa Let's Learn
### Table of Contents

The website contains different pages
1. Home page
It is made up of different sections
* Header setion
It contains a header and some content about the website and a learn more button which directs the user to the lessons page
* Features section
It describes the different features available
* Course section 
It has three lessons which two are available for now and one can enroll by selecting any of the courses
* Registration section
The form is for collecting data from the learns that is to be stored in the database of the E-Learning website. The form is not functional for now.
* Course details section
Gives details about that lesson and one can enroll by selecting the enroll to learn button
* Footer section
2. About page
It is made up of different sections
* Header setion
* About Africa Let's Learn section
* Features section
* Partners section
* Team section
* Footer section
3. Blog page
It is meant to help the learner get more information about different lesson in the module. It has two sections
* Category section
* Article section
4. Lessons page
It is made up of different sections
* Header setion
* Features section
* Course section
* Course details section
* Footer section
5. Contact page
It is made up of different sections
* Header setion
* Features section
* Course section
* Course details section
* Footer section